using System;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CustomerAndAgentManagementSystem.UI.Pages.JavaScriptPractice
{
    public class IndexModel : PageModel
    {
        public void Get()
        {


        }
    }
}
