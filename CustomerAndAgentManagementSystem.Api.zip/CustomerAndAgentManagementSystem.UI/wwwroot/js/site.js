﻿{
    var btn = document.getElementById("btn");
    var customDiv = document.getElementById("customModal");
   
    btn.onclick = function () {
       
    }

}